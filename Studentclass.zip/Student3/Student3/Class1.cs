﻿using System;
using System.Collections.Generic;
using System.Linq;





namespace Student3
{
    public class Class1
    {
        Random rand = new Random();

        public List<Mark> GetMarks(DateTime now, List<Students> students)
        {
            List<string> estimation = new List<string>() { "2", "3", "4", "5", "П", "О", "Б", " " };
            List<Mark> marks = new List<Mark>();
            int len = estimation.Count;

            foreach (Students student in students)
            {
                for (int i = 0; i < 10; i++)
                {
                    int r = rand.Next(len);
                    marks.Add(new Mark
                        (
                            now.AddDays(i),
                            estimation[r],
                            student)
                        );
                }
            }
            return marks;
        }

        public double MinAVG(string[] marks)
        {
            double i = 0;
            double sum = 0;
            foreach (string mark in marks)
            {
                if (int.TryParse(mark, out int est))
                {
                    sum += est;
                    i++;
                }
            }
            string res = (sum / i).ToString();
            if (res.Contains(','))
                return double.Parse(res.Substring(0, res.IndexOf(',') + 2));
            else return double.Parse(res);
        }


        public int[] GetCountTruancy(List<Mark> marks)
        {
            return GetCountPasses(marks, "О");
        }


        public int[] GetCountDisease(List<Mark> marks)
        {
            return GetCountPasses(marks, "Б");
        }

        private static int[] GetCountPasses(List<Mark> marks, string passes)
        {
            Dictionary<int, int> res = new Dictionary<int, int>();
            var tt = (from m in marks
                      group m by m.date.Month into g
                      select new { date = g.Key }).ToList();
            foreach (var t in tt)
            {
                int prom = marks.FindAll(m => m.date.Month == t.date && m.Estimation == passes).Count;
                res.Add(t.date, prom);
            }
            return res.Select(x => x.Value).ToArray();
        }


       
    }

    public class Students
    {
        public int year { get; set; }
        public int group { get; set; }
        public string fio { get; set; }
        public Students(int y, int g, string FIO)
        {
            year = y;
            group = g;
            fio = FIO;
        }
    }

    public class Mark
    {
        public DateTime date { get; set; }
        public string Estimation { get; set; }
        public Students student { get; set; }
        public Mark(DateTime dt, string est, Students std)
        {
            date = dt;
            Estimation = est;
            student = std;
        }
    }
}
